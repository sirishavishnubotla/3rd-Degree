# Person 3 — ML Severity Classifier

## What you built
An AI model that looks at a pothole photo and returns a severity score from 1–5.

- Uses MobileNetV2 — a pretrained image recognition model from Google
- No training from scratch needed — works immediately
- Runs as its own Flask server on port 5001
- Person 2's backend calls it automatically after each photo upload

---

## How to run

### Step 1 — Install dependencies
```
pip install -r requirements.txt
```
> First time only: TensorFlow download is ~500MB, give it 5 minutes on WiFi.

### Step 2 — Start the ML server
```
python model.py
```
You'll see:
```
Loading MobileNetV2 model...
✅ Model loaded!
🚀 ML server starting at http://localhost:5001
```

### Step 3 — Test it's working
Open your browser and go to:
```
http://localhost:5001/test
```
You should see a JSON response with a random severity score. Model is working!

---

## Test with a real image (Postman or curl)

Using curl:
```bash
curl -X POST http://localhost:5001/predict-upload \
  -F "photo=@/path/to/pothole.jpg"
```

Response:
```json
{
  "severity": 4,
  "label": "gravel",
  "confidence": 0.631,
  "message": "Large pothole — repair urgently"
}
```

---

## Severity scale

| Score | Meaning | Action |
|-------|---------|--------|
| 1 | Minor crack | Low priority |
| 2 | Small pothole | Schedule repair |
| 3 | Medium pothole | Fix within 2 weeks |
| 4 | Large / dangerous | Fix urgently |
| 5 | Critical — road destroyed | Fix immediately |

---

## How it works (explain to judges!)

MobileNetV2 was trained by Google on 1.2 million images to recognise
1000 different objects. We don't retrain it — instead we:

1. Feed the pothole photo into the model
2. Look at what the model "sees" (gravel, rubble, mud, stone, etc.)
3. Map those class predictions + confidence scores to severity 1–5
4. Return that score to Person 2's backend in under 1 second

This is called **transfer learning** — using a powerful existing model
as a feature extractor for a new problem. It's the same technique used
in production ML at Google, Meta, and startups worldwide.

---

## If TensorFlow install fails
Run this instead (lighter version):
```
pip install tensorflow-cpu==2.15.0 flask flask-cors numpy Pillow
```
