"""
Person 3 — ML Pothole Severity Classifier
Uses MobileNetV2 (pretrained on ImageNet) to score pothole severity 1-5.
No training needed — works out of the box in under 5 minutes.
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import numpy as np
import os

app = Flask(__name__)
CORS(app)

# ── Load model once at startup ─────────────────────────────────────────────────
print("Loading MobileNetV2 model...")
import tensorflow as tf
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input, decode_predictions
from tensorflow.keras.preprocessing import image as keras_image

model = MobileNetV2(weights="imagenet")
print("✅ Model loaded!")


# ── Severity scoring logic ─────────────────────────────────────────────────────

def score_image(img_path):
    """
    Takes an image path, runs MobileNetV2 on it,
    maps the result to a pothole severity score 1-5.

    How it works:
    - MobileNetV2 was trained on 1000 ImageNet classes
    - We look at the top predicted class and its confidence
    - Road/damage-related classes push severity up
    - High confidence in any prediction also maps to severity
    - This is a SMART HACK — no pothole-specific training needed!
    """
    # Load and preprocess image (MobileNetV2 needs 224x224)
    img = keras_image.load_img(img_path, target_size=(224, 224))
    x   = keras_image.img_to_array(img)
    x   = np.expand_dims(x, axis=0)
    x   = preprocess_input(x)

    # Run prediction
    preds     = model.predict(x, verbose=0)
    top_preds = decode_predictions(preds, top=5)[0]

    # Classes that suggest road damage / rough terrain
    damage_keywords = [
        "gravel", "sandbar", "cliff", "valley", "alp",
        "lakeside", "seashore", "dam", "breakwater",
        "mud", "stone", "rock", "rubble", "debris",
        "construction", "bulldozer", "excavator"
    ]

    # Calculate severity from predictions
    top_label      = top_preds[0][1].lower()
    top_confidence = float(top_preds[0][2])

    # Check if any top-5 labels suggest damage
    damage_score = 0
    for _, label, conf in top_preds:
        label = label.lower().replace("_", " ")
        if any(kw in label for kw in damage_keywords):
            damage_score += conf

    # Map to severity 1-5
    # High confidence in damage-related class = high severity
    severity = map_to_severity(top_confidence, damage_score)

    return severity, top_label, top_confidence


def map_to_severity(confidence, damage_score):
    """
    Smart mapping:
    - damage_score > 0.3  → severe (4-5)
    - confidence > 0.8    → likely clear image of something distinct → medium (3)
    - confidence 0.5-0.8  → ambiguous surface → low-medium (2-3)
    - confidence < 0.5    → very mixed/textured image → likely bad road (3-4)
    """
    if damage_score > 0.5:
        return 5
    elif damage_score > 0.3:
        return 4
    elif damage_score > 0.1:
        return 3
    elif confidence < 0.4:
        # Low confidence = complex/messy image = likely rough road
        return 4
    elif confidence < 0.6:
        return 3
    elif confidence < 0.8:
        return 2
    else:
        return 1


# ── API Endpoints ──────────────────────────────────────────────────────────────

@app.route("/")
def home():
    return jsonify({"message": "ML Severity Model is running!", "port": 5001})


@app.route("/predict", methods=["POST"])
def predict():
    """
    Called by Person 2's backend after saving the photo.
    Body JSON: { "photo_path": "/path/to/photo.jpg" }
    Returns:   { "severity": 3, "label": "gravel", "confidence": 0.72 }
    """
    data       = request.get_json()
    photo_path = data.get("photo_path")

    if not photo_path:
        return jsonify({"error": "photo_path is required"}), 400

    if not os.path.exists(photo_path):
        return jsonify({"error": f"File not found: {photo_path}"}), 404

    try:
        severity, label, confidence = score_image(photo_path)
        return jsonify({
            "severity":   severity,
            "label":      label,
            "confidence": round(confidence, 3),
            "message":    severity_message(severity)
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/predict-upload", methods=["POST"])
def predict_upload():
    """
    Alternative endpoint — accepts photo directly as file upload.
    Useful for testing from browser or Postman.
    """
    if "photo" not in request.files:
        return jsonify({"error": "No photo uploaded"}), 400

    photo = request.files["photo"]
    if photo.filename == "":
        return jsonify({"error": "Empty filename"}), 400

    # Save temporarily
    tmp_path = f"/tmp/pothole_test_{photo.filename}"
    photo.save(tmp_path)

    try:
        severity, label, confidence = score_image(tmp_path)
        os.remove(tmp_path)
        return jsonify({
            "severity":   severity,
            "label":      label,
            "confidence": round(confidence, 3),
            "message":    severity_message(severity)
        })
    except Exception as e:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
        return jsonify({"error": str(e)}), 500


@app.route("/test", methods=["GET"])
def test():
    """
    Quick sanity check — generates a dummy prediction without a real image.
    Open http://localhost:5001/test in browser to verify model is working.
    """
    import random
    fake_severity = random.randint(1, 5)
    return jsonify({
        "status":   "Model is working!",
        "severity": fake_severity,
        "message":  severity_message(fake_severity),
        "note":     "This is a random test — send a real image to /predict-upload"
    })


# ── Helper ─────────────────────────────────────────────────────────────────────

def severity_message(s):
    messages = {
        1: "Minor surface crack — low priority",
        2: "Small pothole — schedule for repair",
        3: "Medium pothole — repair within 2 weeks",
        4: "Large pothole — repair urgently",
        5: "Critical damage — road unsafe, repair immediately!"
    }
    return messages.get(s, "Unknown severity")


# ── Run ────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("🚀 ML server starting at http://localhost:5001")
    print("📸 Send photos to POST /predict or POST /predict-upload")
    print("🔍 Quick test at GET /test")
    app.run(debug=False, port=5001)
